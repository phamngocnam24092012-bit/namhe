package com.autosand.addon;

import com.autosand.addon.modules.AutoSand;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class AutoSandAddon extends MeteorAddon {
    // Tab riêng trong menu Meteor, chứa module Auto Sand.
    public static final Category CATEGORY = new Category("Auto Sand");

    @Override
    public void onInitialize() {
        Modules.get().add(new AutoSand());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.autosand.addon";
    }
}
