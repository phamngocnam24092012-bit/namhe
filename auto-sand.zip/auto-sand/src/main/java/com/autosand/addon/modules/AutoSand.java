package com.autosand.addon.modules;

import com.autosand.addon.AutoSandAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Auto Sand: bật module là tự đào cát ở gần, tự đổi sang đồ đào nhanh nhất
 * (xẻng) trên thanh hotbar, và tự đổi lại slot cũ khi hết cát.
 */
public class AutoSand extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("Khoảng cách tối đa tới khối cát để tự đào.")
        .defaultValue(4.5)
        .min(1)
        .sliderMax(6)
        .build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-switch")
        .description("Tự đổi sang đồ đào cát nhanh nhất trong hotbar (xẻng).")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
        .name("swap-back")
        .description("Tự đổi lại slot cũ khi hết cát hoặc khi tắt module.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> redSand = sgGeneral.add(new BoolSetting.Builder()
        .name("red-sand")
        .description("Đào cả cát đỏ.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> skipUnderFeet = sgGeneral.add(new BoolSetting.Builder()
        .name("skip-under-feet")
        .description("Không đào khối cát ngay dưới chân để tránh bị rơi xuống.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Số tick nghỉ sau mỗi khối cát đã đào.")
        .defaultValue(0)
        .min(0)
        .sliderMax(10)
        .build()
    );

    private boolean swapped;
    private int timer;

    public AutoSand() {
        super(AutoSandAddon.CATEGORY, "auto-sand", "Tự đào cát, tự đổi xẻng và tự đào khi ở gần cát.");
    }

    @Override
    public void onActivate() {
        timer = 0;
        swapped = false;
    }

    @Override
    public void onDeactivate() {
        restoreSlot();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.level == null) return;

        if (timer > 0) {
            timer--;
            return;
        }

        BlockPos target = findSand();
        if (target == null) {
            restoreSlot();
            return;
        }

        if (autoSwitch.get()) {
            int slot = bestToolSlot(mc.level.getBlockState(target));
            if (slot != -1 && InvUtils.swap(slot, swapBack.get())) swapped = true;
        }

        if (BlockUtils.breakBlock(target, true)) timer = delay.get();
    }

    private void restoreSlot() {
        if (swapped && swapBack.get()) InvUtils.swapBack();
        swapped = false;
    }

    private boolean isSand(BlockState state) {
        return state.is(Blocks.SAND) || (redSand.get() && state.is(Blocks.RED_SAND));
    }

    /** Tìm khối cát gần nhất trong tầm đào, hoặc null nếu không có. */
    private BlockPos findSand() {
        double reach = range.get();
        double maxSq = reach * reach;
        int r = (int) Math.ceil(reach);

        BlockPos base = mc.player.blockPosition();
        Vec3 eye = mc.player.getEyePosition();

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    p.set(base.getX() + x, base.getY() + y, base.getZ() + z);

                    if (!isSand(mc.level.getBlockState(p))) continue;
                    if (skipUnderFeet.get() && x == 0 && z == 0 && y == -1) continue;

                    double dist = eye.distanceToSqr(Vec3.atCenterOf(p));
                    if (dist > maxSq || dist >= bestDist) continue;

                    bestDist = dist;
                    best = p.immutable();
                }
            }
        }

        return best;
    }

    /** Slot hotbar (0-8) đào khối này nhanh nhất; -1 nếu không có đồ nào nhanh hơn tay không. */
    private int bestToolSlot(BlockState state) {
        int bestSlot = -1;
        float bestSpeed = 1.0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            float speed = stack.getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        return bestSlot;
    }
}
